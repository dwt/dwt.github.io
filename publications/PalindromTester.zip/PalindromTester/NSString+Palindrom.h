//
//  NSString+Halving.h
//  PalindromTester
//
//  Created by Martin H�cker on Thu Aug 05 2004.
//  Copyright (c) 2004 M-Soft, IT-Dienste. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSString (Palindrom)
- firstHalf;
- secondHalf;
- reverse;
@end
