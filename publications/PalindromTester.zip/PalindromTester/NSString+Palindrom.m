//
//  NSString+Halving.m
//  PalindromTester
//
//  Created by Martin H�cker on Thu Aug 05 2004.
//  Copyright (c) 2004 M-Soft, IT-Dienste. All rights reserved.
//

#import "NSString+Palindrom.h"
#include <math.h>

@implementation NSString (Palindrom)

- firstHalf {
    int middle = [self length] / 2;
    return [self substringToIndex: middle];
}

- secondHalf {
    int middle = ceil([self length] / 2.0);
    return [self substringFromIndex: middle];
}

- reverse {
    id result = [[NSMutableString alloc] init];
    id chars = [self componentsSeparatedByString: @""];
    id each, enumerator = [chars reverseObjectEnumerator];
    while (each = [enumerator nextObject]) {
        [result appendString: each];
    }
    return result;
}

@end