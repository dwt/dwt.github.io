//
//  PalindromTester.h
//  PalindromTester
//
//  Created by Martin H�cker on Thu Aug 05 2004.
//  Copyright (c) 2004 M-Soft, IT-Dienste. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PalindromTester : NSObject {

}

- (BOOL) test: aString;
@end
