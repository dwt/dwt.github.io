//
//  PalindromTester.m
//  PalindromTester
//
//  Created by Martin H�cker on Thu Aug 05 2004.
//  Copyright (c) 2004 M-Soft, IT-Dienste. All rights reserved.
//

#import "PalindromTester.h"


@implementation PalindromTester

- (BOOL) test: aString {
    if ([[aString firstHalf] isEqualTo: [[aString secondHalf] reverse]])
        return YES;
    return NO;
}

@end
