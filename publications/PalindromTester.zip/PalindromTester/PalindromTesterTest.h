//
//  PalindromTesterTest.h
//  PalindromTester
//
//  Created by Martin H�cker on Thu Aug 05 2004.
//  Copyright (c) 2004 M-Soft, IT-Dienste. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>
#import "PalindromTester.h"

@interface PalindromTesterTest : SenTestCase {
    PalindromTester *tester;
}

@end
