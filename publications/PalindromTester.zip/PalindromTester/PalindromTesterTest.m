//
//  PalindromTesterTest.m
//  PalindromTester
//
//  Created by Martin H�cker on Thu Aug 05 2004.
//  Copyright (c) 2004 M-Soft, IT-Dienste. All rights reserved.
//

#import "PalindromTesterTest.h"


@implementation PalindromTesterTest

- (void) setUp {
    tester = [[PalindromTester alloc] init]; }
- (void) tearDown {
    [tester release]; }

- (void) testSimple {
    STAssertTrue([tester test:@""], nil);
    STAssertTrue([tester test:@"a"], nil);
    STAssertTrue([tester test:@"aa"], nil);
    STAssertTrue([tester test:@"aba"], nil);
}

- (void) testFailure {
    STAssertFalse([tester test:@"ab"], nil);
    STAssertFalse([tester test:@"abb"], nil);
    STAssertFalse([tester test:@"abab"], nil);
}
    

@end
