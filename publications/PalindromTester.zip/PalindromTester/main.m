//
//  main.m
//  PalindromTester
//
//  Created by Martin H�cker on Thu Aug 05 2004.
//  Copyright (c) 2004 M-Soft, IT-Dienste. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
