Das Beispielprojekt aus dem Vortrag

Das Projekt l�sst sich einfach �ffnen und kompilieren - wenn oc-unit installiert ist. (Gibts unter: http://sente.epfl.ch/software/ocunit/ )

Das Projekt enth�lt einen fehlschlagenden Test - da m�sste man jetzt weiter programmieren.

:) Have Phun!

cu Martin